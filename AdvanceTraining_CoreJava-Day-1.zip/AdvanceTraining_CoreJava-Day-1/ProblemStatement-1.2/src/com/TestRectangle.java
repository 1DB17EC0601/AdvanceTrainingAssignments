package com;



public class TestRectangle {
	
	public static void main(String[] args) {
		
		Rectangle rc1 = new Rectangle();
		rc1.input();
		rc1.areaOfRectangle();
		rc1.display();
		System.out.println("***********************************");
		Rectangle rc2 = new Rectangle();
		rc2.input();
		rc2.areaOfRectangle();
		rc2.display();
		System.out.println("***********************************");
		Rectangle rc3 = new Rectangle();
		rc3.input();
		rc3.areaOfRectangle();
		rc3.display();
		System.out.println("***********************************");
		Rectangle rc4 = new Rectangle();
		rc4.input();
		rc4.areaOfRectangle();
		rc4.display();
		System.out.println("***********************************");
		Rectangle rc5 = new Rectangle();
		rc5.input();
		rc5.areaOfRectangle();
		rc5.display();
		
		
		
	    
	}

}
