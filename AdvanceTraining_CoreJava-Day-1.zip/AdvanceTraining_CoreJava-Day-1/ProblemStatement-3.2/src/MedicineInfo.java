
public interface MedicineInfo {
	
	
	
   public void displayLabel();



}
