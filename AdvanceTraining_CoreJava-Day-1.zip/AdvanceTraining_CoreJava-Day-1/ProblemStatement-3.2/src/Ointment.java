
public class Ointment implements MedicineInfo{
	
	@Override
	public void displayLabel()
	{
		System.out.println("for external use only");
		System.out.println("Stroe ar temoerature not exceeding 25c");
		System.out.println("Protect from sunlight");
	}
	
	

}
