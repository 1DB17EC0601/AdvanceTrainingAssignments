
public class Syrup implements MedicineInfo{
	
	@Override
	
	public void displayLabel()

	{
		System.out.println("store in a cool dry place");
		System.out.println("keep away from children");
	}
}
