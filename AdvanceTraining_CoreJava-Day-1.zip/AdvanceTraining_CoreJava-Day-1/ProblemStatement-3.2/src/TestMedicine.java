

public class TestMedicine {
	
      String companyName;
      String country;
      
      

	public TestMedicine(String companyName, String country) {
		
		this.companyName = companyName;
		this.country = country;
	}



	public static void main(String[] args) {
	
    TestMedicine m = new TestMedicine("sun pharma", "India");
    
    System.out.println(m.companyName+" "+m.country);
   
    
	Tablet t = new Tablet();
	Syrup s= new Syrup();
	Ointment o = new Ointment();
	
	t.displayLabel();
	
	s.displayLabel();
	o.displayLabel();
	
   
	
}
}
