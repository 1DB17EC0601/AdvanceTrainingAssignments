package com;
import java.util.Scanner;

public class SplitingDemo {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the mathematical expression here..");
		
		String s=sc.nextLine();
		sc.close();
		
		
	    String[] p =s.split(" ");
	    
	    for(String p1:p)
	    	
	    {
	    	System.out.println(p1+" ");
	    }
		
	}

}
